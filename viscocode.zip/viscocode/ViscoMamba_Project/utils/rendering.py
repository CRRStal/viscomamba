import torch

class VolumetricHapticRenderer:
    """Volumetric rendering for haptic fields"""
    
    def __init__(self, num_samples=64):
        self.num_samples = num_samples
    
    def render_haptic_field(self, nerf_model, ray_origins, ray_directions, encoded_features):
        """
        Render haptic field along rays
        Args:
            nerf_model: StiffnessNeRF model
            ray_origins: (batch_size, 3)
            ray_directions: (batch_size, 3)
            encoded_features: (batch_size, encoding_dim)
        Returns:
            rendered stiffness, force, and rgb
        """
        batch_size = ray_origins.shape[0]
        
        # Sample points along rays
        t_vals = torch.linspace(0, 1, self.num_samples, device=ray_origins.device)
        z_vals = t_vals.unsqueeze(0).expand(batch_size, -1)
        
        # Compute 3D points
        points = ray_origins.unsqueeze(1) + ray_directions.unsqueeze(1) * z_vals.unsqueeze(-1)
        
        # Query NeRF
        stiffness, force, rgb = nerf_model(points, encoded_features)
        
        # Volume rendering with quadrature
        weights = self._compute_weights(stiffness.squeeze(-1), z_vals)
        
        rendered_stiffness = (weights * stiffness.squeeze(-1)).sum(dim=1)
        rendered_force = (weights.unsqueeze(-1) * force).sum(dim=1)
        rendered_rgb = (weights.unsqueeze(-1) * rgb).sum(dim=1)
        
        return rendered_stiffness, rendered_force, rendered_rgb
    
    def _compute_weights(self, alpha, z_vals):
        """Compute volumetric rendering weights"""
        dists = z_vals[:, 1:] - z_vals[:, :-1]
        dists = torch.cat([dists, torch.full_like(dists[:, :1], 1e10)], dim=1)
        
        # Alpha compositing
        alpha = 1.0 - torch.exp(-alpha * dists)
        transmittance = torch.cumprod(1.0 - alpha + 1e-10, dim=1)
        transmittance = torch.cat([torch.ones_like(transmittance[:, :1]), transmittance[:, :-1]], dim=1)
        
        weights = alpha * transmittance
        return weights
