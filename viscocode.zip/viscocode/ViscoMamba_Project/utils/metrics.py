import torch
import numpy as np

def compute_rmse(predictions, targets):
    """Compute Root Mean Square Error"""
    mse = torch.mean((predictions - targets) ** 2)
    return torch.sqrt(mse).item()

def compute_lor_latency(predicted_stiffness, threshold=0.85):
    """
    Compute Loss of Routhness (LOR) detection latency
    Args:
        predicted_stiffness: (seq_len,) predicted stiffness values
        threshold: LOR threshold (normalized)
    Returns:
        latency: time steps until LOR detection
    """
    lor_mask = predicted_stiffness < threshold
    if lor_mask.any():
        return torch.argmax(lor_mask.float()).item()
    return len(predicted_stiffness)

def compute_psnr(predictions, targets, max_val=1.0):
    """Compute Peak Signal-to-Noise Ratio"""
    mse = torch.mean((predictions - targets) ** 2)
    if mse == 0:
        return float('inf')
    psnr = 20 * torch.log10(torch.tensor(max_val) / torch.sqrt(mse))
    return psnr.item()

class MetricsTracker:
    """Track multiple metrics during training"""
    
    def __init__(self):
        self.metrics = {}
    
    def update(self, metric_name, value):
        """Update metric with new value"""
        if metric_name not in self.metrics:
            self.metrics[metric_name] = []
        self.metrics[metric_name].append(value)
    
    def get_average(self, metric_name):
        """Get average of metric"""
        if metric_name in self.metrics:
            return np.mean(self.metrics[metric_name])
        return 0.0
    
    def reset(self):
        """Reset all metrics"""
        self.metrics = {}
