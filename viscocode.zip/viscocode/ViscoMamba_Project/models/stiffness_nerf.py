import torch
import torch.nn as nn

class PositionalEncoding(nn.Module):
    """Positional encoding for NeRF"""
    
    def __init__(self, num_freqs=10):
        super().__init__()
        self.num_freqs = num_freqs
    
    def forward(self, x):
        """Apply sinusoidal encoding"""
        encoding = [x]
        for i in range(self.num_freqs):
            encoding.append(torch.sin(2**i * torch.pi * x))
            encoding.append(torch.cos(2**i * torch.pi * x))
        return torch.cat(encoding, dim=-1)

class StiffnessNeRF(nn.Module):
    """Neural Radiance Field for haptic-visual rendering"""
    
    def __init__(self, encoding_dim=64, num_layers=8, hidden_dim=256):
        super().__init__()
        
        self.pos_encoder = PositionalEncoding(num_freqs=10)
        input_dim = 3 * (1 + 2 * 10)  # 3D position with encoding
        
        # MLP layers
        layers = []
        layers.append(nn.Linear(input_dim + encoding_dim, hidden_dim))
        layers.append(nn.ReLU())
        
        for _ in range(num_layers - 2):
            layers.append(nn.Linear(hidden_dim, hidden_dim))
            layers.append(nn.ReLU())
        
        self.mlp = nn.Sequential(*layers)
        
        # Output heads
        self.stiffness_head = nn.Linear(hidden_dim, 1)
        self.force_head = nn.Linear(hidden_dim, 3)
        self.rgb_head = nn.Linear(hidden_dim, 3)
    
    def forward(self, position, encoded_features):
        """
        Args:
            position: 3D spatial position (batch_size, num_points, 3)
            encoded_features: from ViscoMamba (batch_size, encoding_dim)
        Returns:
            stiffness, force, rgb
        """
        # Encode position
        pos_encoded = self.pos_encoder(position)
        
        # Expand features to match points
        batch_size, num_points, _ = position.shape
        features_expanded = encoded_features.unsqueeze(1).expand(-1, num_points, -1)
        
        # Concatenate and process
        x = torch.cat([pos_encoded, features_expanded], dim=-1)
        x = self.mlp(x)
        
        # Predict outputs
        stiffness = torch.sigmoid(self.stiffness_head(x)) * 1000  # Scale to physical range
        force = self.force_head(x)
        rgb = torch.sigmoid(self.rgb_head(x))
        
        return stiffness, force, rgb
