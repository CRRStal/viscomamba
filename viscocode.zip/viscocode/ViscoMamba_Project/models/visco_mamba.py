import torch
import torch.nn as nn

class ViscoMambaBlock(nn.Module):
    """Single Mamba block with selective state space"""
    
    def __init__(self, hidden_dim, state_dim):
        super().__init__()
        self.hidden_dim = hidden_dim
        self.state_dim = state_dim
        
        # Selection mechanism
        self.delta_proj = nn.Linear(hidden_dim, state_dim)
        self.B_proj = nn.Linear(hidden_dim, state_dim)
        self.C_proj = nn.Linear(hidden_dim, state_dim)
        
        # State transition
        self.A = nn.Parameter(torch.randn(state_dim, state_dim))
        
        # Output projection
        self.out_proj = nn.Linear(state_dim, hidden_dim)
    
    def forward(self, x, state=None):
        """
        Args:
            x: input (batch_size, seq_len, hidden_dim)
            state: previous state (batch_size, state_dim)
        Returns:
            output, new_state
        """
        batch_size, seq_len, _ = x.shape
        
        if state is None:
            state = torch.zeros(batch_size, self.state_dim, device=x.device)
        
        outputs = []
        for t in range(seq_len):
            x_t = x[:, t, :]
            
            # Selective parameters
            delta = torch.sigmoid(self.delta_proj(x_t))
            B = self.B_proj(x_t)
            C = self.C_proj(x_t)
            
            # Discretized state space: h_t = A*h_{t-1} + B*x_t
            state = torch.matmul(state, self.A.t()) * delta + B * x_t.unsqueeze(-1).sum(-1)
            
            # Output: y_t = C*h_t
            y_t = self.out_proj(C * state)
            outputs.append(y_t)
        
        return torch.stack(outputs, dim=1), state

class ViscoMambaEncoder(nn.Module):
    """Dual-channel ViscoMamba encoder for haptic-visual fusion"""
    
    def __init__(self, hidden_dim=256, num_layers=6, state_dim=16):
        super().__init__()
        
        # Input embeddings
        self.haptic_embed = nn.Linear(3, hidden_dim)  # force input
        self.visual_embed = nn.Linear(3, hidden_dim)  # position/visual input
        
        # Mamba blocks
        self.haptic_blocks = nn.ModuleList([
            ViscoMambaBlock(hidden_dim, state_dim) for _ in range(num_layers)
        ])
        self.visual_blocks = nn.ModuleList([
            ViscoMambaBlock(hidden_dim, state_dim) for _ in range(num_layers)
        ])
        
        # Cross-attention fusion
        self.fusion = nn.MultiheadAttention(hidden_dim, num_heads=8)
        
    def forward(self, haptic_data, visual_data):
        """
        Args:
            haptic_data: force signals (batch_size, seq_len, 3)
            visual_data: visual/position data (batch_size, seq_len, 3)
        Returns:
            fused_features: (batch_size, seq_len, hidden_dim)
        """
        # Embed inputs
        h = self.haptic_embed(haptic_data)
        v = self.visual_embed(visual_data)
        
        # Process through Mamba blocks
        h_state, v_state = None, None
        for h_block, v_block in zip(self.haptic_blocks, self.visual_blocks):
            h, h_state = h_block(h, h_state)
            v, v_state = v_block(v, v_state)
        
        # Cross-modal fusion
        h_t = h.transpose(0, 1)  # (seq_len, batch, hidden_dim)
        v_t = v.transpose(0, 1)
        
        fused, _ = self.fusion(h_t, v_t, v_t)
        fused = fused.transpose(0, 1)  # (batch, seq_len, hidden_dim)
        
        return fused
