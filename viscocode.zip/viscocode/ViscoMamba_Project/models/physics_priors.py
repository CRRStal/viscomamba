import torch
import torch.nn as nn

class KelvinVoigtPrior(nn.Module):
    """Physics-based prior using Kelvin-Voigt viscoelastic model"""
    
    def __init__(self, k_init=1000.0, eta_init=50.0):
        super().__init__()
        # Learnable physical parameters
        self.k = nn.Parameter(torch.tensor(k_init))
        self.eta = nn.Parameter(torch.tensor(eta_init))
    
    def forward(self, displacement, velocity):
        """
        Compute force based on Kelvin-Voigt model: F = k*x + eta*v
        Args:
            displacement: deformation (batch_size, seq_len, 3)
            velocity: velocity (batch_size, seq_len, 3)
        Returns:
            force: predicted force (batch_size, seq_len, 3)
        """
        elastic_force = self.k * displacement
        viscous_force = self.eta * velocity
        total_force = elastic_force + viscous_force
        
        return total_force
    
    def get_parameters(self):
        """Return learned physical parameters"""
        return {
            'stiffness': self.k.item(),
            'viscosity': self.eta.item()
        }

class PhysicsInitializer(nn.Module):
    """Initialize state space with physics-informed priors"""
    
    def __init__(self, state_dim, k=1000.0, eta=50.0):
        super().__init__()
        self.state_dim = state_dim
        self.kelvin_voigt = KelvinVoigtPrior(k, eta)
        
        # Projection layer
        self.proj = nn.Linear(6, state_dim)  # [displacement, velocity] -> state
    
    def forward(self, displacement, velocity):
        """Initialize state with physics knowledge"""
        # Compute physics-based force
        force = self.kelvin_voigt(displacement, velocity)
        
        # Concatenate kinematics
        kinematics = torch.cat([displacement, velocity], dim=-1)
        
        # Project to state space
        initial_state = self.proj(kinematics)
        
        return initial_state, force
