import torch
import torch.nn as nn

class LuGreObserver(nn.Module):
    def __init__(self, sigma0, sigma1, sigma2, fc, fs, vs, k_obs, dt=0.001):
        """
        LuGre 动态摩擦力模型观测器
        Args:
            sigma0: 刷毛刚度
            sigma1: 微观阻尼系数
            sigma2: 宏观粘性摩擦系数
            fc: 库仑摩擦力
            fs: 最大静摩擦力
            vs: Stribeck 速度
            k_obs: 观测器增益
            dt: 采样时间步长
        """
        super().__init__()
        self.sigma0 = sigma0
        self.sigma1 = sigma1
        self.sigma2 = sigma2
        self.fc = fc
        self.fs = fs
        self.vs = vs
        self.k_obs = k_obs
        self.dt = dt
        
        # 内部状态 z (刷毛平均形变), 初始化为 0
        self.register_buffer('z_hat', torch.zeros(1))

    def g_v(self, v):
        """稳态摩擦特性 g(v)"""
        return self.fc + (self.fs - self.fc) * torch.exp(-(v / self.vs) ** 2)

    def forward(self, v_t, f_meas):
        """
        输入:
            v_t: 针尖速度 (来自运动学)
            f_meas: 传感器测量的原始力 F_raw
        输出:
            f_tip: 解耦后的纯净穿刺力 (Cutting Force)
        """
        # 1. 计算 g(v)
        g = self.g_v(v_t)
        
        # 2. 计算 z 的导数 (包含观测器修正项)
        # 预测的摩擦力 f_fric_hat
        z_dot_pred = v_t - (self.sigma0 * torch.abs(v_t) / g) * self.z_hat
        f_fric_hat = self.sigma0 * self.z_hat + self.sigma1 * z_dot_pred + self.sigma2 * v_t
        
        # 观测误差反馈
        observer_correction = self.k_obs * (f_meas - f_fric_hat)
        
        # 更新 z_hat (欧拉积分)
        dz_dt = v_t - (self.sigma0 * torch.abs(v_t) / g) * self.z_hat + observer_correction
        self.z_hat = self.z_hat + dz_dt * self.dt
        
        # 3. 计算最终的摩擦力并解耦
        # 注意：这里使用更新后的 z_hat 再次计算更准确
        f_fric_final = self.sigma0 * self.z_hat + self.sigma1 * dz_dt + self.sigma2 * v_t
        f_tip = f_meas - f_fric_final
        
        return f_tip