import numpy as np
from scipy import signal
from scipy.fft import fft, fftfreq

class SpectralAnalyzer:
    """Spectral analysis and synchronization for multi-modal data"""
    
    def __init__(self, sampling_rate=1000):
        self.sampling_rate = sampling_rate
    
    def compute_spectrum(self, signal_data):
        """Compute frequency spectrum of signal"""
        N = len(signal_data)
        yf = fft(signal_data)
        xf = fftfreq(N, 1 / self.sampling_rate)
        return xf[:N//2], np.abs(yf[:N//2])
    
    def synchronize_signals(self, force_data, visual_data, timestamps):
        """Synchronize force and visual data using cross-correlation"""
        # Resample to common time base
        common_time = np.linspace(timestamps.min(), timestamps.max(), len(timestamps))
        
        force_sync = np.interp(common_time, timestamps, force_data)
        visual_sync = np.interp(common_time, timestamps, visual_data)
        
        return force_sync, visual_sync, common_time
    
    def apply_bandpass_filter(self, data, lowcut=1.0, highcut=100.0, order=4):
        """Apply bandpass filter to remove noise"""
        nyquist = 0.5 * self.sampling_rate
        low = lowcut / nyquist
        high = highcut / nyquist
        
        b, a = signal.butter(order, [low, high], btype='band')
        filtered_data = signal.filtfilt(b, a, data)
        
        return filtered_data
