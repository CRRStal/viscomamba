import torch
import yaml
import numpy as np

from models.visco_mamba import ViscoMambaEncoder
from models.stiffness_nerf import StiffnessNeRF
from models.physics_priors import PhysicsInitializer
from utils.rendering import VolumetricHapticRenderer
from utils.metrics import compute_lor_latency

class ViscoMambaInference:
    """Inference and control for ViscoMamba"""
    
    def __init__(self, config_path='configs/default_config.yaml', checkpoint_path=None):
        with open(config_path, 'r') as f:
            self.config = yaml.safe_load(f)
        
        self.device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
        
        # Load models
        self.encoder = ViscoMambaEncoder(
            hidden_dim=self.config['model']['visco_mamba']['hidden_dim'],
            num_layers=self.config['model']['visco_mamba']['num_layers'],
            state_dim=self.config['model']['visco_mamba']['state_dim']
        ).to(self.device)
        
        self.nerf = StiffnessNeRF(
            encoding_dim=self.config['model']['nerf']['encoding_dim'],
            num_layers=self.config['model']['nerf']['num_layers'],
            hidden_dim=self.config['model']['nerf']['hidden_dim']
        ).to(self.device)
        
        self.renderer = VolumetricHapticRenderer()
        
        if checkpoint_path:
            self.load_checkpoint(checkpoint_path)
        
        self.encoder.eval()
        self.nerf.eval()
    
    def load_checkpoint(self, checkpoint_path):
        """Load model checkpoint"""
        checkpoint = torch.load(checkpoint_path, map_location=self.device)
        self.encoder.load_state_dict(checkpoint['encoder'])
        self.nerf.load_state_dict(checkpoint['nerf'])
    
    @torch.no_grad()
    def predict(self, haptic_data, visual_data, position):
        """
        Predict stiffness and force at given position
        Args:
            haptic_data: force signals (batch_size, seq_len, 3)
            visual_data: visual data (batch_size, seq_len, 3)
            position: query position (batch_size, 3)
        Returns:
            stiffness, force, rgb
        """
        # Encode features
        encoded = self.encoder(haptic_data, visual_data)
        
        # Take last time step encoding
        encoded_last = encoded[:, -1, :]
        
        # Render at position
        ray_directions = torch.zeros_like(position)
        ray_directions[:, 2] = 1.0  # Forward direction
        
        stiffness, force, rgb = self.renderer.render_haptic_field(
            self.nerf, position, ray_directions, encoded_last
        )
        
        return stiffness, force, rgb
    
    def detect_lor(self, stiffness_sequence):
        """
        Detect Loss of Routhness (LOR)
        Args:
            stiffness_sequence: (seq_len,) temporal stiffness values
        Returns:
            is_lor: boolean indicating LOR detection
            latency: detection latency
        """
        threshold = self.config['inference']['lor_threshold']
        latency = compute_lor_latency(stiffness_sequence, threshold)
        is_lor = latency < len(stiffness_sequence)
        
        return is_lor, latency
    
    def impedance_control(self, current_force, desired_force, velocity):
        """
        Impedance control for safe interaction
        Args:
            current_force: measured force (3,)
            desired_force: target force (3,)
            velocity: current velocity (3,)
        Returns:
            control_force: control output (3,)
        """
        damping = self.config['inference']['impedance_control']['damping']
        inertia = self.config['inference']['impedance_control']['inertia']
        
        force_error = desired_force - current_force
        
        # Simple PD control
        control_force = force_error - damping * velocity
        
        return control_force

if __name__ == '__main__':
    # Example usage
    inference = ViscoMambaInference(checkpoint_path='checkpoint_epoch_100.pt')
    
    # Dummy data
    haptic = torch.randn(1, 50, 3)
    visual = torch.randn(1, 50, 3)
    position = torch.randn(1, 3)
    
    stiffness, force, rgb = inference.predict(haptic, visual, position)
    print(f"Predicted stiffness: {stiffness}")
    print(f"Predicted force: {force}")
